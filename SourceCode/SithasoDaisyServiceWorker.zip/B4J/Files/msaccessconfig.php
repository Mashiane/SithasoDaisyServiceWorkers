<?php
const DB_NAME = 'C:\\laragon\\www\\bvad3msaccessphp\\assets\\estore.accdb';
const DB_USER = '';
const DB_PASS = '';
?>